import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'dart:ui_web' as ui_web; // Import the web-specific dart:ui_web library
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:typed_data';

import 'package:firebase_core/firebase_core.dart';
import 'package:crud_app/screen/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Check if running in web context
  if (kIsWeb) {
    ui_web.setPluginHandler(
        (String data, ByteData? response, void Function(ByteData?)? callback) {
      // Handle plugin messages
      print('Received plugin message: $data');
      // You can implement your handling logic here
    });
  }

  await Firebase.initializeApp(
    options: FirebaseOptions(
        apiKey: 'AIzaSyB53NnbjjtHoHwBtj6lOIbHGMpMCXSqELQ',
        authDomain: 'toyboom-e2c1f.firebaseapp.com',
        projectId: 'toyboom-e2c1f',
        messagingSenderId: '58973995004',
        appId: '1:58973995004:web:7ae9d0dd024de9b5c9fc79'),
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Web - Firebase CRUD',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}
