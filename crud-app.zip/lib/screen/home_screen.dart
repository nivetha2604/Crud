import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:crud_app/Model/product.dart';

class HomeScreen extends StatefulWidget {
  HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final CollectionReference productsCollection =
      FirebaseFirestore.instance.collection('PRODUCTS');

  List<Product> products = [];

  @override
  void initState() {
    super.initState();
    readProducts();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('PRODUCTS'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: products.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(products[index].name),
                    subtitle: Text(
                      'SubProduct: ${products[index].subName}, Price: ${products[index].price}',
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () {
                        deleteProduct(products[index].name);
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showCreateProductDialog(context);
        },
        child: Icon(Icons.add),
      ),
    );
  }

  Future<void> createProduct(Product product) async {
    await productsCollection.add(product.toMap());
    readProducts(); // Refresh the product list
  }

  void readProducts() {
    productsCollection.get().then((QuerySnapshot querySnapshot) {
      List<Product> productList = [];
      querySnapshot.docs.forEach((doc) {
        productList.add(Product(
          name: doc['name'],
          subName: doc['subName'],
          price: doc['price'],
        ));
      });
      setState(() {
        products = productList;
      });
    });
  }

  Future<void> updateProduct(String productName, Product updatedProduct) async {
    await productsCollection
        .where('name', isEqualTo: productName)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        doc.reference.update(updatedProduct.toMap());
      });
    });
    readProducts(); // Refresh the product list
  }

  Future<void> deleteProduct(String productName) async {
    await productsCollection
        .where('name', isEqualTo: productName)
        .get()
        .then((QuerySnapshot querySnapshot) {
      querySnapshot.docs.forEach((doc) {
        doc.reference.delete();
      });
    });
    readProducts(); // Refresh the product list
  }

  Future<void> _showCreateProductDialog(BuildContext context) async {
    TextEditingController nameController = TextEditingController();
    TextEditingController subNameController = TextEditingController();
    TextEditingController priceController = TextEditingController();

    await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Create Product'),
          content: Column(
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(labelText: 'Name'),
              ),
              TextField(
                controller: subNameController,
                decoration: InputDecoration(labelText: 'SubName'),
              ),
              TextField(
                controller: priceController,
                decoration: InputDecoration(labelText: 'Price'),
                keyboardType: TextInputType.number,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                // Create the product and close the dialog
                createProduct(
                  Product(
                    name: nameController.text,
                    subName: subNameController.text,
                    price: double.parse(priceController.text),
                  ),
                );
                Navigator.of(context).pop();
              },
              child: Text('Create'),
            ),
          ],
        );
      },
    );
  }
}
