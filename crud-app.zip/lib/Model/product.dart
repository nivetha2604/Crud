class Product {
  late String name;
  late String subName;
  late double price;

  Product({required this.name, required this.subName, required this.price});

  Map<String, dynamic> toMap() {
    return {
      'Name': name,
      'SubName': subName,
      'Price': price,
    };
  }
}
